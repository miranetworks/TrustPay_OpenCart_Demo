<?php
// Heading
$_['heading_title'] = 'Waiting for Payment!';

// Text
$_['text_basket']   = 'Shopping Cart';
$_['text_checkout'] = 'Checkout';
$_['text_failure']  = 'Waiting for Payment';
$_['text_message']  = '<p>Waiting for payment confirmation.</p>

<p>If the confirmation fails please <a href="%s">contact us</a> with the details of the order you are trying to place.</p>
';
